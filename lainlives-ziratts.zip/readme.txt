lainlives' custom soundpack
generated with microsoft zira and various ladspa filters
